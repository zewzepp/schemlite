# SchemLite (Fabric, client-side, Minecraft 26.3)

Press **M** for the menu. No chat commands, no chat messages.

| What | How |
|---|---|
| Menu | **M** (Mode, rotate, nudge, save, Builds, Material list, Settings) |
| Pick corners | Stick + right-click blocks (SELECT mode). Sneak+click = normal vanilla use |
| Place the build | PLACE mode: stick + right-click sets the origin; use -X/+X etc. in the menu to nudge |
| Switch mode | Sneak + scroll while holding the stick (changeable in Settings), or **X** |
| Rotate | **R** (full circle: 0, 90, 180, 270) |
| Print | **G** (Hold or Toggle - Settings). Build box turns green while printing |
| Builds | Menu > Builds: load / delete. Shared by every world |
| Build Files | Menu > Build Files: Export copies a build to config/schemlite/exports (send that .sl file to a friend). To import, drop a received .sl into config/schemlite/imports, then Import |
| Litematica | Menu > Build Files > Litematica lists .litematic files from .minecraft/schematics. Click one: it is converted, saved to Builds with the same name and loaded at your position |
| Material list | All Blocks / Missing Blocks tabs. The Highlight button (or H) outlines every block still to place in pulsing red, visible through walls |
| Settings | Print key hold/toggle, Air place, Print speed (2-80 blocks/sec), Mode-switch scroll, Ghost boxes |

Notes: double slabs place one half; chests/signs contents are not saved; chest-type blocks may be skipped.
