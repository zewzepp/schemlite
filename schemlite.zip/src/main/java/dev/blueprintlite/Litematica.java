package dev.blueprintlite;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.zip.GZIPInputStream;

/** Reads Litematica (.litematic) files into a SchemLite {@link Schematic}. Has its own tiny NBT reader. */
public final class Litematica {

    @SuppressWarnings("unchecked")
    public static Schematic read(Path file) throws IOException {
        Map<String, Object> root;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new GZIPInputStream(Files.newInputStream(file))))) {
            if (in.readByte() != 10) throw new IOException("Not a Litematica file");
            in.readUTF();
            root = (Map<String, Object>) readTag(in, (byte) 10);
        } catch (IOException e) { throw e; }
        catch (Exception e) { throw new IOException("Not a Litematica file"); }

        Object regionsObj = root.get("Regions");
        if (!(regionsObj instanceof Map)) throw new IOException("No regions in file");
        Map<String, Object> regions = (Map<String, Object>) regionsObj;

        // pass 1: work out each region's min corner and the combined bounding box
        List<int[]> info = new ArrayList<>();            // minX,minY,minZ, sizeX,sizeY,sizeZ
        List<Map<String, Object>> list = new ArrayList<>();
        int gx0 = Integer.MAX_VALUE, gy0 = Integer.MAX_VALUE, gz0 = Integer.MAX_VALUE;
        int gx1 = Integer.MIN_VALUE, gy1 = Integer.MIN_VALUE, gz1 = Integer.MIN_VALUE;
        for (Object ro : regions.values()) {
            Map<String, Object> r = (Map<String, Object>) ro;
            Map<String, Object> pos = (Map<String, Object>) r.get("Position");
            Map<String, Object> size = (Map<String, Object>) r.get("Size");
            int px = num(pos.get("x")), py = num(pos.get("y")), pz = num(pos.get("z"));
            int sx = num(size.get("x")), sy = num(size.get("y")), sz = num(size.get("z"));
            int ax = Math.abs(sx), ay = Math.abs(sy), az = Math.abs(sz);
            int mx = px + (sx < 0 ? sx + 1 : 0), my = py + (sy < 0 ? sy + 1 : 0), mz = pz + (sz < 0 ? sz + 1 : 0);
            info.add(new int[]{mx, my, mz, ax, ay, az});
            list.add(r);
            gx0 = Math.min(gx0, mx); gy0 = Math.min(gy0, my); gz0 = Math.min(gz0, mz);
            gx1 = Math.max(gx1, mx + ax); gy1 = Math.max(gy1, my + ay); gz1 = Math.max(gz1, mz + az);
        }
        if (list.isEmpty()) throw new IOException("File has no blocks");
        long vol = (long) (gx1 - gx0) * (gy1 - gy0) * (gz1 - gz0);
        if (vol <= 0 || vol > 8_000_000L) throw new IOException("Build too big (max 8 million blocks)");

        Schematic out = new Schematic(gx1 - gx0, gy1 - gy0, gz1 - gz0);
        int missing = 0;

        // pass 2: unpack every region into the combined schematic
        for (int k = 0; k < list.size(); k++) {
            Map<String, Object> r = list.get(k);
            int[] f = info.get(k);
            List<Object> pal = (List<Object>) r.get("BlockStatePalette");
            long[] data = (long[]) r.get("BlockStates");
            if (pal == null || data == null || pal.isEmpty()) continue;

            BlockState[] states = new BlockState[pal.size()];
            for (int i = 0; i < states.length; i++) {
                BlockState st = StateIO.parse(stateKey((Map<String, Object>) pal.get(i)));
                if (st == null) { st = Blocks.AIR.defaultBlockState(); missing++; }
                states[i] = st;
            }

            int bits = Math.max(2, 32 - Integer.numberOfLeadingZeros(states.length - 1));
            long mask = (1L << bits) - 1;
            int sx = f[3], sy = f[4], sz = f[5];
            for (int y = 0; y < sy; y++)
                for (int z = 0; z < sz; z++)
                    for (int x = 0; x < sx; x++) {
                        long i = ((long) y * sz + z) * sx + x;
                        long bit = i * bits;
                        int li = (int) (bit >>> 6), off = (int) (bit & 63);
                        if (li >= data.length) continue;
                        long v = data[li] >>> off;
                        if (off + bits > 64 && li + 1 < data.length) v |= data[li + 1] << (64 - off);
                        int id = (int) (v & mask);
                        if (id >= states.length) continue;
                        BlockState st = states[id];
                        if (st.isAir()) continue;   // never overwrite another region's blocks with air
                        out.blocks[out.idx(f[0] - gx0 + x, f[1] - gy0 + y, f[2] - gz0 + z)] = st;
                    }
        }
        if (missing > 0) BP.msg(missing + " unknown block type(s) were replaced with air.");
        return out;
    }

    /** Same text format StateIO uses: name[prop=value,...] with properties sorted by name. */
    @SuppressWarnings("unchecked")
    private static String stateKey(Map<String, Object> entry) {
        StringBuilder sb = new StringBuilder((String) entry.get("Name"));
        Object po = entry.get("Properties");
        if (po instanceof Map && !((Map<String, Object>) po).isEmpty()) {
            TreeMap<String, Object> props = new TreeMap<>((Map<String, Object>) po);
            sb.append('[');
            boolean first = true;
            for (var e : props.entrySet()) {
                if (!first) sb.append(',');
                first = false;
                sb.append(e.getKey()).append('=').append(e.getValue());
            }
            sb.append(']');
        }
        return sb.toString();
    }

    private static int num(Object o) { return ((Number) o).intValue(); }

    // ---------------------------------------------------------------- NBT
    private static Object readTag(DataInputStream in, byte type) throws IOException {
        switch (type) {
            case 1: return in.readByte();
            case 2: return in.readShort();
            case 3: return in.readInt();
            case 4: return in.readLong();
            case 5: return in.readFloat();
            case 6: return in.readDouble();
            case 7: { byte[] a = new byte[in.readInt()]; in.readFully(a); return a; }
            case 8: return in.readUTF();
            case 9: {
                byte et = in.readByte();
                int n = in.readInt();
                List<Object> l = new ArrayList<>(Math.max(0, n));
                for (int i = 0; i < n; i++) l.add(readTag(in, et));
                return l;
            }
            case 10: {
                Map<String, Object> m = new HashMap<>();
                while (true) {
                    byte t = in.readByte();
                    if (t == 0) break;
                    String name = in.readUTF();
                    m.put(name, readTag(in, t));
                }
                return m;
            }
            case 11: { int[] a = new int[in.readInt()]; for (int i = 0; i < a.length; i++) a[i] = in.readInt(); return a; }
            case 12: { long[] a = new long[in.readInt()]; for (int i = 0; i < a.length; i++) a[i] = in.readLong(); return a; }
            default: throw new IOException("Bad NBT tag " + type);
        }
    }
    private Litematica() {}
}
