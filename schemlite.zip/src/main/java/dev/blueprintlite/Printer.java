package dev.blueprintlite;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/** Places schematic blocks near the player. Survival + creative, optional air-place. */
public final class Printer {
    static final double REACH = 4.5;
    static final int MAX_TRIES = 20;
    /** Properties the printer can't control (set by neighbours / redstone / defaults) - mismatches are ignored. */
    static final Set<String> TOLERATE = Set.of("waterlogged", "powered", "lit", "triggered", "open", "shape",
            "north", "east", "south", "west", "up", "hinge", "distance", "persistent", "snowy", "power",
            "delay", "locked", "attached", "in_wall", "instrument", "note", "occupied");
    static final float[] YAWS = {0f, 90f, 180f, 270f};
    static final float[] PITCHES = {0f, -89f, 89f};
    static final double[] FYS = {0.25, 0.75};

    public static boolean running = false;   // true while actively printing (overlay turns green)
    public static boolean toggled = false;   // state for TOGGLE mode

    private static double budget = 0;
    private static int returnSlot = -1;
    private static int creativeSlot = -1;
    private static ItemStack creativeSaved = ItemStack.EMPTY;
    private static final Map<Long, Integer> recent = new HashMap<>();
    private static int now = 0;

    public static boolean skip(BlockState s) {
        if (s.isAir()) return true;
        if (s.getBlock() instanceof LiquidBlock) return true;
        if (s.getBlock().asItem() == Items.AIR) return true;
        if (s.hasProperty(BlockStateProperties.DOUBLE_BLOCK_HALF)
                && s.getValue(BlockStateProperties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.UPPER) return true;
        if (s.hasProperty(BlockStateProperties.BED_PART)
                && s.getValue(BlockStateProperties.BED_PART) == BedPart.HEAD) return true;
        return false;
    }

    public static void reset() {
        running = false; toggled = false; budget = 0;
        returnSlot = -1; creativeSlot = -1; creativeSaved = ItemStack.EMPTY; recent.clear();
    }

    /** Give back the player's hotbar exactly as it was (fixes the creative "stick turns into blocks" bug). */
    public static void stop(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null) { reset(); return; }
        if (creativeSlot >= 0) {
            if (p.isCreative()) mc.gameMode.handleCreativeModeItemAdd(creativeSaved, 36 + creativeSlot);
            creativeSlot = -1;
            creativeSaved = ItemStack.EMPTY;
        }
        if (returnSlot >= 0) {
            p.getInventory().setSelectedSlot(returnSlot);
            returnSlot = -1;
        }
        budget = 0;
    }

    public static void tick(Minecraft mc) {
        Schematic s = BP.schem;
        LocalPlayer p = mc.player;
        ClientLevel lv = mc.level;
        if (s == null || BP.origin == null || p == null || lv == null || mc.gameMode == null) return;
        now++;
        double perTick = Settings.bps() / 20.0;
        budget = Math.min(budget + perTick, Math.max(1.0, perTick));
        if (budget < 1) return;

        BlockPos o = BP.origin, c = p.blockPosition();
        int r = (int) Math.ceil(REACH) + 1;
        List<BlockPos> cands = new ArrayList<>();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int x = Math.max(o.getX(), c.getX() - r); x <= Math.min(o.getX() + s.sx - 1, c.getX() + r); x++)
            for (int y = Math.max(o.getY(), c.getY() - r); y <= Math.min(o.getY() + s.sy - 1, c.getY() + r); y++)
                for (int z = Math.max(o.getZ(), c.getZ() - r); z <= Math.min(o.getZ() + s.sz - 1, c.getZ() + r); z++) {
                    BlockState target = s.get(x - o.getX(), y - o.getY(), z - o.getZ());
                    if (skip(target)) continue;
                    BlockState have = lv.getBlockState(m.set(x, y, z));
                    if (have == target || !have.canBeReplaced()) continue;
                    cands.add(new BlockPos(x, y, z));
                }
        Vec3 eye = p.getEyePosition();
        cands.sort(Comparator.<BlockPos>comparingInt(BlockPos::getY)
                .thenComparingDouble(b -> b.distToCenterSqr(eye.x, eye.y, eye.z)));

        int tries = 0;
        for (BlockPos pos : cands) {
            if (budget < 1 || tries >= MAX_TRIES) break;
            Integer t = recent.get(pos.asLong());
            if (t != null && now - t < 4) continue;       // just placed, waiting for the server
            tries++;
            BlockState target = s.get(pos.getX() - o.getX(), pos.getY() - o.getY(), pos.getZ() - o.getZ());
            if (tryPlace(mc, p, lv, pos, target, eye)) { budget -= 1; recent.put(pos.asLong(), now); }
        }
        if (now % 100 == 0) recent.values().removeIf(v -> now - v > 40);
    }

    private static boolean interactive(BlockState st) {
        return st.hasBlockEntity()
                || st.is(BlockTags.DOORS) || st.is(BlockTags.TRAPDOORS) || st.is(BlockTags.BUTTONS)
                || st.is(BlockTags.FENCE_GATES) || st.is(BlockTags.BEDS) || st.is(BlockTags.ANVIL)
                || st.is(Blocks.LEVER) || st.is(Blocks.CRAFTING_TABLE) || st.is(Blocks.NOTE_BLOCK)
                || st.is(Blocks.REPEATER) || st.is(Blocks.COMPARATOR);
    }

    static boolean matches(BlockState got, BlockState target) {
        for (Property<?> prop : target.getProperties()) {
            if (TOLERATE.contains(prop.getName())) continue;
            if (!got.hasProperty(prop) || !got.getValue(prop).equals(target.getValue(prop))) return false;
        }
        return true;
    }

    private static boolean tryPlace(Minecraft mc, LocalPlayer p, ClientLevel lv, BlockPos pos,
                                    BlockState target, Vec3 eye) {
        Item item = target.getBlock().asItem();
        if (!(item instanceof BlockItem)) return false;
        boolean creative = p.isCreative();
        Inventory inv = p.getInventory();

        int slot = -1;
        for (int i = 0; i < 36; i++) if (inv.getItem(i).is(item)) { slot = i; break; }
        if (slot < 0 && !creative) return false;
        if (creative && slot >= 9) slot = -1;   // creative: just conjure it

        // 1. every way we could click to place this block
        List<BlockHitResult> opts = new ArrayList<>();
        for (Direction d : Direction.values()) {
            BlockPos n = pos.relative(d);
            BlockState ns = lv.getBlockState(n);
            if (ns.isAir() || ns.canBeReplaced() || interactive(ns)) continue;
            Direction face = d.getOpposite();
            Vec3 base = Vec3.atCenterOf(n).add(face.getStepX() * 0.5, face.getStepY() * 0.5, face.getStepZ() * 0.5);
            if (base.distanceTo(eye) > REACH) continue;
            if (face.getAxis().isHorizontal()) {
                for (double fy : FYS) opts.add(new BlockHitResult(new Vec3(base.x, n.getY() + fy, base.z), face, n, false));
            } else {
                opts.add(new BlockHitResult(base, face, n, false));
            }
        }
        if (opts.isEmpty() && Settings.airPlace && Vec3.atCenterOf(pos).distanceTo(eye) <= REACH) {
            for (Direction face : Direction.values())
                for (double fy : FYS)
                    opts.add(new BlockHitResult(new Vec3(pos.getX() + 0.5, pos.getY() + fy, pos.getZ() + 0.5), face, pos, false));
        }
        if (opts.isEmpty()) return false;

        // 2. find a look direction + click that gives EXACTLY the wanted state (stairs, logs, etc.)
        float oy = p.getYRot(), ox = p.getXRot();
        ItemStack sim = new ItemStack(item);
        BlockHitResult bestHit = null;
        float bestYaw = oy, bestPitch = ox;
        outer:
        for (BlockHitResult hr : opts) for (float yaw : YAWS) for (float pitch : PITCHES) {
            p.setYRot(yaw); p.setXRot(pitch);
            BlockState got = target.getBlock().getStateForPlacement(new BlockPlaceContext(p, InteractionHand.MAIN_HAND, sim, hr));
            if (got != null && matches(got, target)) { bestHit = hr; bestYaw = yaw; bestPitch = pitch; break outer; }
        }
        p.setYRot(oy); p.setXRot(ox);
        if (bestHit == null) return false;

        // 3. put the item in hand (never destroys what you were holding)
        equip(mc, p, item, slot);

        // 4. look the right way, place, look back
        sendRot(p, bestYaw, bestPitch);
        mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND, bestHit);
        sendRot(p, oy, ox);
        return true;
    }

    private static void equip(Minecraft mc, LocalPlayer p, Item item, int slot) {
        Inventory inv = p.getInventory();
        if (returnSlot < 0) returnSlot = inv.getSelectedSlot();
        if (slot >= 0 && slot < 9) {
            inv.setSelectedSlot(slot);
        } else if (slot >= 9) {
            int dest = -1;
            for (int i = 0; i < 9; i++) if (inv.getItem(i).isEmpty()) { dest = i; break; }
            if (dest < 0) dest = inv.getSelectedSlot();
            inv.setSelectedSlot(dest);
            mc.gameMode.handleContainerInput(p.inventoryMenu.containerId, slot, dest, ContainerInput.SWAP, p);
        } else {
            if (creativeSlot < 0) {
                creativeSlot = inv.getSelectedSlot();
                creativeSaved = inv.getItem(creativeSlot).copy();   // remembered, restored in stop()
            }
            inv.setSelectedSlot(creativeSlot);
            mc.gameMode.handleCreativeModeItemAdd(new ItemStack(item, 64), 36 + creativeSlot);
        }
    }

    private static void sendRot(LocalPlayer p, float yaw, float pitch) {
        p.connection.send(new ServerboundMovePlayerPacket.Rot(yaw, pitch, p.onGround(), p.horizontalCollision));
    }
    private Printer() {}
}
