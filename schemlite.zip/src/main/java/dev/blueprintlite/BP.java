package dev.blueprintlite;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

import java.lang.reflect.Method;

/** Shared mod state + small helpers. Nothing here writes to chat. */
public final class BP {
    public enum Mode { SELECT, PLACE }

    public static Mode mode = Mode.SELECT;
    public static BlockPos pos1, pos2;     // selection corners
    public static BlockPos origin;         // min-corner of the placed schematic
    public static Schematic schem;         // currently loaded schematic (already rotated)
    public static Schematic base;          // the schematic as saved (rotation 0)
    public static int rot = 0;             // 0..3 = 0, 90, 180, 270 degrees
    public static boolean nextIsPos2 = false;
    public static boolean showMissing = false;   // highlight not-yet-placed blocks through walls
    public static String status = "Hold a stick and right-click blocks to pick corners.";

    /** Status text is only shown inside the menu (never in chat). */
    public static void msg(String s) { status = s; }

    public static void toggleMode() {
        mode = mode == Mode.SELECT ? Mode.PLACE : Mode.SELECT;
        status = "Mode: " + mode;
        actionBar("SchemLite mode: " + mode);
    }

    public static void setSchem(Schematic s) { base = s; schem = s; rot = 0; }

    public static void clearSchem() { base = null; schem = null; rot = 0; showMissing = false; }

    public static int rotDeg() { return rot * 90; }

    /** Full circle: 0 -> 90 -> 180 -> 270 -> 0. Rotates around the build's centre so it stays in place. */
    public static void rotate() {
        if (schem == null || base == null) { status = "No build loaded."; return; }
        Schematic old = schem;
        rot = (rot + 1) & 3;
        schem = base.rotated(rot);
        if (origin != null) origin = origin.offset((old.sx - schem.sx) / 2, 0, (old.sz - schem.sz) / 2);
        status = "Rotation: " + rotDeg() + " degrees.";
        actionBar("SchemLite rotation: " + rotDeg() + "°");
    }

    /** Small action-bar hint (not chat). Silently does nothing if the API differs. */
    public static void actionBar(String s) {
        try {
            Minecraft mc = Minecraft.getInstance();
            Object gui = Minecraft.class.getField("gui").get(mc);
            Method m = gui.getClass().getMethod("setOverlayMessage", Component.class, boolean.class);
            m.invoke(gui, Component.literal(s), false);
        } catch (Throwable ignored) { }
    }

    /** Opens a screen; tries the 26.2+ name first, then the older one. */
    public static void openScreen(Screen screen) {
        Minecraft mc = Minecraft.getInstance();
        for (String name : new String[]{"setScreenAndShow", "setScreen"}) {
            try {
                Method m = Minecraft.class.getDeclaredMethod(name, Screen.class);
                m.setAccessible(true);
                m.invoke(mc, screen);
                return;
            } catch (NoSuchMethodException ignored) {
            } catch (Throwable t) { t.printStackTrace(); return; }
        }
    }
    private BP() {}
}
