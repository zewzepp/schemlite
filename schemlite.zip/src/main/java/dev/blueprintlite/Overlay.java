package dev.blueprintlite;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * Wireframe overlay. SELECT mode shows your selection; PLACE mode shows the build.
 * Build box is white, turns GREEN while the printer is running.
 * Blue box = block still missing, red box = wrong block in the way.
 */
public final class Overlay {
    private static final int RANGE = 14, MAX_BOXES = 1500;

    private static final int MISSING_MAX = 3000, MISSING_RANGE = 96;
    private static final int MISSING_COLOR = 0xFFFF00FF;   // bright magenta
    private static long[] missing = new long[0];
    private static int missingN = 0;
    private static long lastScan = 0;
    private static java.lang.reflect.Method topM;
    private static boolean topResolved = false;

    /** Makes a gizmo render through blocks (looked up by name so a rename can't break the build). */
    private static void onTop(Object props) {
        if (props == null) return;
        try {
            if (!topResolved) {
                topResolved = true;
                try { topM = props.getClass().getMethod("setAlwaysOnTop"); topM.setAccessible(true); } catch (Throwable ignored) { }
            }
            if (topM != null) topM.invoke(props);
        } catch (Throwable ignored) { }
    }

    /** Every block of the build that is not in the world yet (air or the wrong block), drawn through walls. */
    private static void renderMissing(Minecraft mc) {
        Schematic s = BP.schem;
        BlockPos o = BP.origin;
        if (s == null || o == null) return;
        long nowMs = System.currentTimeMillis();
        if (nowMs - lastScan > 400) {   // rescan a few times a second, not every frame
            lastScan = nowMs;
            if (missing.length < MISSING_MAX) missing = new long[MISSING_MAX];
            missingN = 0;
            BlockPos c = mc.player.blockPosition();
            BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
            scan:
            for (int y = Math.max(o.getY(), c.getY() - MISSING_RANGE); y <= Math.min(o.getY() + s.sy - 1, c.getY() + MISSING_RANGE); y++)
                for (int x = Math.max(o.getX(), c.getX() - MISSING_RANGE); x <= Math.min(o.getX() + s.sx - 1, c.getX() + MISSING_RANGE); x++)
                    for (int z = Math.max(o.getZ(), c.getZ() - MISSING_RANGE); z <= Math.min(o.getZ() + s.sz - 1, c.getZ() + MISSING_RANGE); z++) {
                        BlockState t = s.get(x - o.getX(), y - o.getY(), z - o.getZ());
                        if (Printer.skip(t)) continue;
                        BlockState w = mc.level.getBlockState(m.set(x, y, z));
                        if (w.getBlock() == t.getBlock() && Printer.matches(w, t)) continue;
                        missing[missingN++] = BlockPos.asLong(x, y, z);
                        if (missingN >= MISSING_MAX) break scan;
                    }
        }
        for (int i = 0; i < missingN; i++) {
            long l = missing[i];
            int x = BlockPos.getX(l), y = BlockPos.getY(l), z = BlockPos.getZ(l);
            onTop(Gizmos.cuboid(new AABB(x + 0.05, y + 0.05, z + 0.05, x + 0.95, y + 0.95, z + 0.95), GizmoStyle.stroke(MISSING_COLOR)));
        }
    }

    public static void render() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (BP.showMissing) renderMissing(mc);

        if (BP.mode == BP.Mode.SELECT) {
            if (BP.pos1 != null) box(BP.pos1, BP.pos1, 0xFFFFFF00);
            if (BP.pos2 != null) box(BP.pos2, BP.pos2, 0xFF00FFFF);
            if (BP.pos1 != null && BP.pos2 != null) box(BP.pos1, BP.pos2, 0xFF00FF66);
            return;
        }

        Schematic s = BP.schem;
        BlockPos o = BP.origin;
        if (s == null || o == null) return;
        box(o, o.offset(s.sx - 1, s.sy - 1, s.sz - 1), Printer.running ? 0xFF00FF00 : 0xFFFFFFFF);
        if (!Settings.ghost) return;

        BlockPos c = mc.player.blockPosition();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        int drawn = 0;
        for (int y = Math.max(o.getY(), c.getY() - RANGE); y <= Math.min(o.getY() + s.sy - 1, c.getY() + RANGE); y++)
            for (int x = Math.max(o.getX(), c.getX() - RANGE); x <= Math.min(o.getX() + s.sx - 1, c.getX() + RANGE); x++)
                for (int z = Math.max(o.getZ(), c.getZ() - RANGE); z <= Math.min(o.getZ() + s.sz - 1, c.getZ() + RANGE); z++) {
                    BlockState t = s.get(x - o.getX(), y - o.getY(), z - o.getZ());
                    if (t.isAir()) continue;
                    BlockState w = mc.level.getBlockState(m.set(x, y, z));
                    if (w == t) continue;
                    int color = w.canBeReplaced() ? 0xFF3A7BFF : 0xFFFF3030;
                    Gizmos.cuboid(new AABB(x + 0.15, y + 0.15, z + 0.15, x + 0.85, y + 0.85, z + 0.85), GizmoStyle.stroke(color));
                    if (++drawn >= MAX_BOXES) return;
                }
    }

    private static void box(BlockPos a, BlockPos b, int color) {
        AABB bb = new AABB(Math.min(a.getX(), b.getX()), Math.min(a.getY(), b.getY()), Math.min(a.getZ(), b.getZ()),
                Math.max(a.getX(), b.getX()) + 1, Math.max(a.getY(), b.getY()) + 1, Math.max(a.getZ(), b.getZ()) + 1);
        Gizmos.cuboid(bb, GizmoStyle.stroke(color));
    }
    private Overlay() {}
}
