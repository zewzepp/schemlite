package dev.blueprintlite;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/** The "Builds" library: every .sl file in config/schemlite/schematics, shared by all worlds. */
public final class Library {
    public static Path root() { return FabricLoader.getInstance().getConfigDir().resolve("schemlite"); }
    public static Path dir() { return root().resolve("schematics"); }
    /** Builds you export land here - send these files to other players. */
    public static Path exportDir() { return root().resolve("exports"); }
    /** Put files you received from other players here, then import them from the menu. */
    public static Path importDir() { return root().resolve("imports"); }

    /** Where Litematica keeps its files: .minecraft/schematics */
    public static Path litematicaDir() { return FabricLoader.getInstance().getGameDir().resolve("schematics"); }

    public static List<String> list() { return listIn(dir(), ".sl"); }

    public static List<String> listIn(Path d) { return listIn(d, ".sl"); }

    public static List<String> listIn(Path d, String ext) {
        if (!Files.exists(d)) return new ArrayList<>();
        try (Stream<Path> f = Files.list(d)) {
            return f.map(p -> p.getFileName().toString())
                    .filter(n -> n.toLowerCase().endsWith(ext))
                    .map(n -> n.substring(0, n.length() - ext.length()))
                    .sorted(String.CASE_INSENSITIVE_ORDER)
                    .collect(Collectors.toList());
        } catch (IOException e) { return new ArrayList<>(); }
    }

    public static void delete(String name) {
        try { Files.deleteIfExists(dir().resolve(name + ".sl")); } catch (IOException ignored) { }
    }

    /** Copies a saved build into the exports folder. */
    public static Path export(String name) throws IOException {
        Files.createDirectories(exportDir());
        Path out = exportDir().resolve(name + ".sl");
        Files.copy(dir().resolve(name + ".sl"), out, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        return out;
    }

    /** Validates a file from the imports folder and copies it into your builds. Returns the name it was saved as. */
    public static String importFile(String name) throws IOException {
        Path src = importDir().resolve(name + ".sl");
        Schematic.load(src);   // throws if it isn't a valid SchemLite file
        Files.createDirectories(dir());
        String n = name;
        int i = 1;
        while (Files.exists(dir().resolve(n + ".sl"))) n = name + "_" + (i++);
        Files.copy(src, dir().resolve(n + ".sl"));
        return n;
    }

    /** Opens a folder in the system file browser (created if missing). Silent on failure. */
    public static void openFolder(Path d) {
        try {
            Files.createDirectories(d);
            String os = System.getProperty("os.name", "").toLowerCase();
            String[] cmd = os.contains("win") ? new String[]{"explorer", d.toString()}
                    : os.contains("mac") ? new String[]{"open", d.toString()}
                    : new String[]{"xdg-open", d.toString()};
            new ProcessBuilder(cmd).start();
        } catch (Exception ignored) { }
    }

    public static String clean(String s) {
        String c = s == null ? "" : s.trim().replaceAll("[^A-Za-z0-9_\\-]", "_");
        return c.isEmpty() ? "build" : c;
    }
    private Library() {}
}
