package dev.schemlite;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** User settings, edited in the menu and saved to config/schemlite/settings.properties */
public final class Settings {
    public static final int[] SPEEDS = {2, 5, 10, 20, 40, 80};   // blocks per second

    public static boolean printToggle = false;  // false = hold key, true = press to toggle
    public static boolean airPlace = false;     // place blocks with no neighbour to attach to
    public static boolean ghost = true;         // draw missing/wrong block boxes
    public static int speedIdx = 2;             // index into SPEEDS
    public static int scrollMode = 1;           // 0 = off, 1 = sneak + scroll, 2 = scroll

    public static int bps() { return SPEEDS[Math.max(0, Math.min(SPEEDS.length - 1, speedIdx))]; }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("schemlite").resolve("settings.properties");
    }

    public static void load() {
        try (InputStream in = Files.newInputStream(file())) {
            Properties p = new Properties();
            p.load(in);
            printToggle = Boolean.parseBoolean(p.getProperty("printToggle", "false"));
            airPlace = Boolean.parseBoolean(p.getProperty("airPlace", "false"));
            ghost = Boolean.parseBoolean(p.getProperty("ghost", "true"));
            speedIdx = Integer.parseInt(p.getProperty("speedIdx", "2"));
            scrollMode = Integer.parseInt(p.getProperty("scrollMode", "1"));
        } catch (Exception ignored) { }
    }

    public static void save() {
        try {
            Files.createDirectories(file().getParent());
            Properties p = new Properties();
            p.setProperty("printToggle", String.valueOf(printToggle));
            p.setProperty("airPlace", String.valueOf(airPlace));
            p.setProperty("ghost", String.valueOf(ghost));
            p.setProperty("speedIdx", String.valueOf(speedIdx));
            p.setProperty("scrollMode", String.valueOf(scrollMode));
            try (OutputStream out = Files.newOutputStream(file())) { p.store(out, "SchemLite"); }
        } catch (IOException ignored) { }
    }
    private Settings() {}
}
