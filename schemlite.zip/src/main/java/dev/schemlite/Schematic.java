package dev.schemlite;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/** A block-only blueprint. Stored in config/schemlite/schematics/NAME.sl */
public final class Schematic {
    public final int sx, sy, sz;
    public final BlockState[] blocks;

    public Schematic(int sx, int sy, int sz) {
        this.sx = sx; this.sy = sy; this.sz = sz;
        this.blocks = new BlockState[sx * sy * sz];
        Arrays.fill(blocks, Blocks.AIR.defaultBlockState());
    }

    public int idx(int x, int y, int z) { return (y * sz + z) * sx + x; }
    public BlockState get(int x, int y, int z) { return blocks[idx(x, y, z)]; }

    public static Schematic capture(Level level, BlockPos a, BlockPos b) {
        int x0 = Math.min(a.getX(), b.getX()), x1 = Math.max(a.getX(), b.getX());
        int y0 = Math.min(a.getY(), b.getY()), y1 = Math.max(a.getY(), b.getY());
        int z0 = Math.min(a.getZ(), b.getZ()), z1 = Math.max(a.getZ(), b.getZ());
        Schematic s = new Schematic(x1 - x0 + 1, y1 - y0 + 1, z1 - z0 + 1);
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int y = 0; y < s.sy; y++)
            for (int z = 0; z < s.sz; z++)
                for (int x = 0; x < s.sx; x++)
                    s.blocks[s.idx(x, y, z)] = level.getBlockState(m.set(x0 + x, y0 + y, z0 + z));
        return s;
    }

    /** Rotate 90° clockwise (seen from above). */
    public Schematic rotatedCW() { return rotated(1); }

    /** Rotate by q quarter-turns clockwise (0..3 = 0, 90, 180, 270 degrees). Always computed from this schematic. */
    public Schematic rotated(int q) {
        q = Math.floorMod(q, 4);
        if (q == 0) return this;
        Rotation rot = Rotation.values()[q];   // NONE, CLOCKWISE_90, CLOCKWISE_180, COUNTERCLOCKWISE_90
        boolean swap = (q & 1) == 1;
        Schematic r = swap ? new Schematic(sz, sy, sx) : new Schematic(sx, sy, sz);
        for (int y = 0; y < sy; y++)
            for (int z = 0; z < sz; z++)
                for (int x = 0; x < sx; x++) {
                    int nx, nz;
                    switch (q) {
                        case 1 -> { nx = sz - 1 - z; nz = x; }
                        case 2 -> { nx = sx - 1 - x; nz = sz - 1 - z; }
                        default -> { nx = z; nz = sx - 1 - x; }
                    }
                    r.blocks[r.idx(nx, y, nz)] = get(x, y, z).rotate(rot);
                }
        return r;
    }

    public void save(Path file) throws IOException {
        Files.createDirectories(file.getParent());
        Map<BlockState, Integer> palette = new LinkedHashMap<>();
        for (BlockState s : blocks) palette.putIfAbsent(s, palette.size());
        try (DataOutputStream out = new DataOutputStream(new GZIPOutputStream(Files.newOutputStream(file)))) {
            out.writeUTF("BPL1");
            out.writeInt(sx); out.writeInt(sy); out.writeInt(sz);
            out.writeInt(palette.size());
            for (BlockState s : palette.keySet()) out.writeUTF(StateIO.key(s));
            for (BlockState s : blocks) out.writeInt(palette.get(s));
        }
    }

    public static Schematic load(Path file) throws IOException {
        try (DataInputStream in = new DataInputStream(new GZIPInputStream(Files.newInputStream(file)))) {
            if (!in.readUTF().equals("BPL1")) throw new IOException("Not a SchemLite file");
            Schematic s = new Schematic(in.readInt(), in.readInt(), in.readInt());
            int n = in.readInt();
            BlockState[] pal = new BlockState[n];
            int missing = 0;
            for (int i = 0; i < n; i++) {
                BlockState st = StateIO.parse(in.readUTF());
                if (st == null) { st = Blocks.AIR.defaultBlockState(); missing++; }
                pal[i] = st;
            }
            for (int i = 0; i < s.blocks.length; i++) s.blocks[i] = pal[in.readInt()];
            if (missing > 0) BP.msg(missing + " unknown block type(s) were replaced with air.");
            return s;
        }
    }
}
