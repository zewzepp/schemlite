package dev.schemlite;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.util.List;

/** The M menu. Built only from buttons / text / one text box. Every button has a hover tooltip. */
public class MenuScreen extends Screen {
    private enum Page { MAIN, BUILDS, MATERIALS, SETTINGS, FILES }

    private Page page = Page.MAIN;
    private String nameText = "";
    private int buildPage = 0, matPage = 0;
    private boolean matAll = true;
    private int filesTab = 0;   // 0 = export, 1 = import, 2 = litematica
    private int filePage = 0;
    private String armedDelete = null;

    // layout grid: every button is 20 tall, 3px apart, two half-width columns
    private static final int W = 197, HALF = 97, H = 20, G = 3, ROW = 23;

    public MenuScreen() { super(Component.literal("SchemLite")); }

    private Button btn(String label, int x, int y, int w, String tip, Runnable r) {
        return btnF(label, null, x, y, w, tip, r);
    }

    /** Same as btn, but the label can be coloured (used to mark the active tab). */
    private Button btnF(String label, net.minecraft.ChatFormatting fmt, int x, int y, int w, String tip, Runnable r) {
        Component text = fmt == null ? Component.literal(label) : Component.literal(label).withStyle(fmt);
        Button b = Button.builder(text, bt -> r.run()).bounds(x, y, w, H).build();
        b.setAlpha(0f);   // vanilla art invisible; the button still clicks and shows its tooltip
        addRenderableWidget(b);
        // 40% black tint, rounded corners (40% of the height), light blue rounded outline, faint blue tint on hover
        addRenderableOnly((g, mx, my, pt) -> {
            Hud.roundFill(g, x, y, w, H, 0x66000000);
            if (mx >= x && mx < x + w && my >= y && my < y + H) Hud.roundFill(g, x, y, w, H, 0x3355CCFF);
            Hud.roundFrame(g, x, y, w, H);
        });
        net.minecraft.client.gui.Font font = Minecraft.getInstance().font;
        int tw = font.width(text);
        addRenderableWidget(new StringWidget(x + (w - tw) / 2, y + 6, tw, 8, text, font));
        if (tip != null && !noTip(label)) b.setTooltip(Tooltip.create(Component.literal(tip)));
        return b;
    }

    /** Self-explanatory buttons get no hover text; only the ones that need explaining do. */
    private static boolean noTip(String label) {
        String[] plain = {"Rotate", "-", "+", "Save", "Builds", "Material", "Settings", "Back", "<", ">",
                "Load", "Delete", "Sure", "All Blocks", "Missing Blocks", "Export", "[Export", "Import", "[Import", "Open "};
        for (String s : plain) if (label.startsWith(s)) return true;
        return false;
    }

    /** Rounded light blue outline around the page (no background). */
    private void panel(int x, int y, int w, int h) {
        addRenderableOnly((g, mx, my, pt) -> Hud.roundFrame(g, x, y, w, h));
    }

    private void header(String s, int x, int y, int w) {
        addRenderableWidget(new StringWidget(x, y, w, 12,
                Component.literal(s).withStyle(net.minecraft.ChatFormatting.AQUA, net.minecraft.ChatFormatting.BOLD),
                Minecraft.getInstance().font));
    }

    private void text(String s, int x, int y, int w) {
        addRenderableWidget(new StringWidget(x, y, w, 12,
                Component.literal(s).withStyle(net.minecraft.ChatFormatting.GRAY), Minecraft.getInstance().font));
    }

    /** Grey text centred on cx. */
    private void ctext(String s, int cx, int y) {
        int tw = Minecraft.getInstance().font.width(s);
        text(s, cx - tw / 2, y, tw + 2);
    }

    private void go(Page p) { page = p; armedDelete = null; rebuildWidgets(); }

    @Override
    public void removed() { Settings.save(); }

    @Override
    protected void init() {
        int ph = switch (page) { case MAIN -> 233; case BUILDS -> 190; case MATERIALS -> 208; case SETTINGS -> 149; case FILES -> 225; };
        int top = Math.max(2, (this.height - ph) / 2);
        int x0 = this.width / 2 - W / 2;
        panel(x0 - 10, top, W + 20, ph);
        int y = top + 8;
        switch (page) {
            case MAIN -> main(x0, y);
            case BUILDS -> builds(x0, y);
            case MATERIALS -> materials(x0, y);
            case SETTINGS -> settings(x0, y);
            case FILES -> files(x0, y);
        }
    }

    /** Previous / page label / next row, symmetric. */
    private int navRow(int x0, int y, int cur, int pages, Runnable prev, Runnable next) {
        btn("<", x0, y, 40, "Previous page.", prev);
        ctext("Page " + (cur + 1) + "/" + pages, x0 + W / 2, y + 5);
        btn(">", x0 + W - 40, y, 40, "Next page.", next);
        return y + ROW;
    }

    // ------------------------------------------------------------------ MAIN
    private void main(int x0, int y) {
        int rx = x0 + HALF + G;   // right column
        header("SchemLite", x0, y, W); y += 12;
        text(BP.status, x0, y, W); y += 14;

        // Row 1:  Mode | -X X -Y Y      Row 2:  Rotate | (gap) -Z Z
        btn("Mode: " + BP.mode, x0, y, HALF,
                "Switch between SELECT (pick two corners with the stick) and PLACE (position and print a loaded build).",
                () -> { BP.toggleMode(); rebuildWidgets(); });
        String[] lab = {"-X", "+X", "-Y", "+Y", "-Z", "+Z"};
        String[] tips = {"Move the build 1 block west.", "Move the build 1 block east.",
                "Move the build 1 block down.", "Move the build 1 block up.",
                "Move the build 1 block north.", "Move the build 1 block south."};
        int[][] d = {{-1, 0, 0}, {1, 0, 0}, {0, -1, 0}, {0, 1, 0}, {0, 0, -1}, {0, 0, 1}};
        int sw = 22, step = sw + G;   // 4 small buttons: 4*22 + 3*3 = 97 = one half
        for (int i = 0; i < 6; i++) {
            final int k = i;
            int col = i < 4 ? i : i - 2;      // Z buttons sit under the Y buttons
            int by = i < 4 ? y : y + ROW;
            btn(lab[i], rx + col * step, by, sw, tips[i], () -> {
                if (BP.origin == null) BP.status = "Load or place a build first.";
                else { BP.origin = BP.origin.offset(d[k][0], d[k][1], d[k][2]); BP.status = "Moved to " + BP.origin.toShortString(); }
                rebuildWidgets();
            });
        }
        y += ROW;
        btn("Rotate: " + BP.rotDeg() + "° (R)", x0, y, HALF,
                "Turn the loaded build 90° clockwise. Cycles 0° > 90° > 180° > 270° > back to 0°.",
                () -> { BP.rotate(); rebuildWidgets(); });
        y += ROW;

        text("Name of Build", x0, y, W); y += 11;
        EditBox box = new EditBox(Minecraft.getInstance().font, x0, y, W, 18, Component.literal("Name of Build"));
        box.setValue(nameText);
        box.setResponder(s -> nameText = s);
        addRenderableWidget(box);
        y += 22;

        btn("Save Build", x0, y, HALF,
                "Save the blocks between your two selected corners as a build with the name above.",
                this::saveSelection);
        btn("Origin to Player", rx, y, HALF,
                "Move the loaded build so its corner is at the block you are standing on.",
                () -> {
                    var p = Minecraft.getInstance().player;
                    if (p != null && BP.schem != null) { BP.origin = p.blockPosition(); BP.status = "Origin set to your position."; }
                    else BP.status = "Load a build first.";
                    rebuildWidgets();
                });
        y += ROW;

        btn("Builds", x0, y, HALF,
                "Open your saved builds. Load or delete them. Shared by every world.",
                () -> go(Page.BUILDS));
        btn("Materials", rx, y, HALF,
                "Show every block (and how many) the loaded build needs.",
                () -> { matPage = 0; go(Page.MATERIALS); });
        y += ROW;

        btn("Build Files", x0, y, W,
                "Export your builds to share with other players, or import builds you received from them.",
                () -> { filePage = 0; go(Page.FILES); });
        y += ROW;

        btn("Settings", x0, y, HALF,
                "Change print key behaviour, print speed and other options.",
                () -> go(Page.SETTINGS));
        btn("Clear Selection", rx, y, HALF,
                "Clears your selected corners and removes the placed or loaded build.",
                () -> {
                    BP.clearSchem(); BP.showMissing = false; BP.origin = null; BP.pos1 = null; BP.pos2 = null;
                    BP.nextIsPos2 = false; BP.mode = BP.Mode.SELECT; BP.status = BP.DEFAULT_STATUS;
                    rebuildWidgets();
                });
        y += ROW;

        btn("Back", x0 + (W - HALF) / 2, y, HALF, "Close this menu.", this::onClose);
    }

    private void saveSelection() {
        Minecraft mc = Minecraft.getInstance();
        if (BP.pos1 == null || BP.pos2 == null || mc.level == null) {
            BP.status = "Pick two corners with the stick first."; rebuildWidgets(); return;
        }
        BlockPos a = BP.pos1, b = BP.pos2;
        long vol = (long) (Math.abs(a.getX() - b.getX()) + 1) * (Math.abs(a.getY() - b.getY()) + 1) * (Math.abs(a.getZ() - b.getZ()) + 1);
        if (vol > 8_000_000L) { BP.status = "Selection too big (max 8 million blocks)."; rebuildWidgets(); return; }
        String name = Library.clean(nameText);
        Schematic s = Schematic.capture(mc.level, a, b);
        try {
            s.save(Library.dir().resolve(name + ".sl"));
            BP.status = "Saved '" + name + "' (" + s.sx + "x" + s.sy + "x" + s.sz + ")";
        } catch (IOException e) { BP.status = "Save failed: " + e.getMessage(); }
        rebuildWidgets();
    }

    // ---------------------------------------------------------------- BUILDS
    private void builds(int x0, int y) {
        header("Builds", x0, y, W); y += 16;
        List<String> names = Library.list();
        int per = 5;
        int pages = Math.max(1, (names.size() + per - 1) / per);
        buildPage = Math.max(0, Math.min(buildPage, pages - 1));
        if (names.isEmpty()) text("No builds yet.", x0, y + 4, W);
        for (int i = 0; i < per; i++) {
            int idx = buildPage * per + i;
            if (idx < names.size()) {
                final String n = names.get(idx);
                btn("Load: " + n, x0, y, W - 47 - G, "Load this build and switch to PLACE mode.", () -> loadBuild(n));
                btn(n.equals(armedDelete) ? "Sure?" : "Delete", x0 + W - 47, y, 47,
                        "Delete this build permanently. Click twice to confirm.", () -> {
                    if (n.equals(armedDelete)) { Library.delete(n); armedDelete = null; BP.status = "Deleted " + n; }
                    else armedDelete = n;
                    rebuildWidgets();
                });
            }
            y += ROW;
        }
        y = navRow(x0, y, buildPage, pages, () -> { buildPage--; rebuildWidgets(); }, () -> { buildPage++; rebuildWidgets(); });
        btn("Back", x0, y, W, "Return to the main menu.", () -> go(Page.MAIN));
    }

    private void loadBuild(String name) {
        var p = Minecraft.getInstance().player;
        try {
            BP.setSchem(Schematic.load(Library.dir().resolve(name + ".sl")));
            BP.origin = p != null ? p.blockPosition() : BlockPos.ZERO;
            BP.mode = BP.Mode.PLACE;
            BP.status = "Loaded '" + name + "'. Right-click with stick to move it.";
            onClose();
        } catch (IOException e) { BP.status = "Load failed: " + e.getMessage(); rebuildWidgets(); }
    }

    // ------------------------------------------------------------- MATERIALS
    private void materials(int x0, int y) {
        header("Material list", x0, y, W); y += 16;
        btnF("All Blocks", matAll ? net.minecraft.ChatFormatting.YELLOW : null, x0, y, HALF,
                "Show every block the whole build needs.",
                () -> { matAll = true; matPage = 0; rebuildWidgets(); });
        btnF("Missing Blocks", !matAll ? net.minecraft.ChatFormatting.YELLOW : null, x0 + HALF + G, y, HALF,
                "Show only the materials that are still missing.",
                () -> { matAll = false; matPage = 0; rebuildWidgets(); });
        y += ROW;
        List<String> lines = Materials.compute(matAll);
        int per = 8;
        int pages = Math.max(1, (lines.size() + per - 1) / per);
        matPage = Math.max(0, Math.min(matPage, pages - 1));
        for (int i = 0; i < per; i++) {
            int idx = matPage * per + i;
            if (idx < lines.size()) text(lines.get(idx), x0 + 2, y, W);
            y += 13;
        }
        y += 6;
        y = navRow(x0, y, matPage, pages, () -> { matPage--; rebuildWidgets(); }, () -> { matPage++; rebuildWidgets(); });
        btn("Back", x0, y, W, "Return to the main menu.", () -> go(Page.MAIN));
    }

    // ----------------------------------------------------------------- FILES
    private void files(int x0, int y) {
        header("Build Files", x0, y, W); y += 12;
        text(BP.status, x0, y, W); y += 14;
        String[] tn = {"Export", "Import", "Litematica"};
        String[] tt = {"Copy one of your builds to the exports folder so you can send the file to another player.",
                "Add a build file you received from another player to your builds.",
                "Use a .litematic file from Litematica: it is converted, saved to your builds and loaded ready to place."};
        int[] tw = {63, 65, 63};   // 63 + 3 + 65 + 3 + 63 = 197
        int tx = x0;
        for (int i = 0; i < 3; i++) {
            final int k = i;
            btn(filesTab == i ? "[" + tn[i] + "]" : tn[i], tx, y, tw[i], tt[i], () -> { filesTab = k; filePage = 0; rebuildWidgets(); });
            tx += tw[i] + G;
        }
        y += 24;

        List<String> names = filesTab == 0 ? Library.list()
                : filesTab == 1 ? Library.listIn(Library.importDir())
                : Library.listIn(Library.litematicaDir(), ".litematic");
        int per = 4;
        int pages = Math.max(1, (names.size() + per - 1) / per);
        filePage = Math.max(0, Math.min(filePage, pages - 1));
        if (names.isEmpty()) {
            text(filesTab == 0 ? "No builds to export. Save a build first."
                    : filesTab == 1 ? "No files found in the imports folder."
                    : "No .litematic files in .minecraft/schematics.", x0, y + 4, W);
        }
        for (int i = 0; i < per; i++) {
            int idx = filePage * per + i;
            if (idx < names.size()) {
                final String n = names.get(idx);
                if (filesTab == 0) {
                    btn("Export: " + n, x0, y, W,
                            "Copy this build to the exports folder. Use 'Open Export Folder' to find the file and send it.",
                            () -> {
                                try { Library.export(n); BP.status = "Exported '" + n + "'. Open the export folder."; }
                                catch (IOException e) { BP.status = "Export failed: " + e.getMessage(); }
                                rebuildWidgets();
                            });
                } else if (filesTab == 1) {
                    btn("Import: " + n, x0, y, W,
                            "Add this file to your builds. It will then show up in Builds.",
                            () -> {
                                try { BP.status = "Imported as '" + Library.importFile(n) + "'."; }
                                catch (Exception e) { BP.status = "Import failed: not a valid build file."; }
                                rebuildWidgets();
                            });
                } else {
                    btn("Use: " + n, x0, y, W,
                            "Convert this Litematica file, save it to your builds under the same name and load it at your position. Right-click with a stick to move it.",
                            () -> useLitematic(n));
                }
            }
            y += ROW;
        }
        y = navRow(x0, y, filePage, pages, () -> { filePage--; rebuildWidgets(); }, () -> { filePage++; rebuildWidgets(); }) + 1;

        btn(filesTab == 0 ? "Open Export Folder" : filesTab == 1 ? "Open Import Folder" : "Open Litematica Folder", x0, y, W,
                filesTab == 0 ? "Open the folder with your exported builds. Send these .sl files to other players."
                : filesTab == 1 ? "Open the folder where received .sl files go. Drop the files here, then come back and click Import."
                : "Open .minecraft/schematics, where Litematica saves its .litematic files.",
                () -> Library.openFolder(filesTab == 0 ? Library.exportDir() : filesTab == 1 ? Library.importDir() : Library.litematicaDir()));
        y += ROW;
        btn("Back", x0, y, W, "Return to the main menu.", () -> go(Page.MAIN));
    }

    private void useLitematic(String fileName) {
        var p = Minecraft.getInstance().player;
        try {
            Schematic s = Litematica.read(Library.litematicaDir().resolve(fileName + ".litematic"));
            String name = Library.clean(fileName);
            s.save(Library.dir().resolve(name + ".sl"));
            BP.setSchem(s);
            BP.origin = p != null ? p.blockPosition() : BlockPos.ZERO;
            BP.mode = BP.Mode.PLACE;
            BP.status = "Loaded '" + name + "' from Litematica.";
            onClose();
        } catch (Exception e) {
            BP.status = "Litematica import failed: " + e.getMessage();
            rebuildWidgets();
        }
    }

    // -------------------------------------------------------------- SETTINGS
    /** Print speed slider, 1 - 100. Vanilla art is hidden; the rounded bar and label are drawn here. */
    private class SpeedSlider extends AbstractSliderButton {
        SpeedSlider(int x, int y, int w) {
            super(x, y, w, H, Component.empty(), (Settings.speed - 1) / 99.0);
            updateMessage();
        }
        @Override protected void updateMessage() { setMessage(Component.empty()); }
        @Override protected void applyValue() { Settings.speed = 1 + (int) Math.round(this.value * 99.0); }
    }

    private void settings(int x0, int y) {
        header("Settings", x0, y, W); y += 16;
        btn("Print: " + (Settings.printToggle ? "Toggle" : "Hold"), x0, y, W,
                "Hold: the printer runs only while you hold the print key. Toggle: press once to start printing, press again to stop.",
                () -> { Settings.printToggle = !Settings.printToggle; Printer.toggled = false; Settings.save(); rebuildWidgets(); });
        y += ROW;
        btn("Air Place: " + (Settings.airPlace ? "On" : "Off"), x0, y, W,
                "Allows placing blocks that have no neighbouring block to attach to (floating blocks). Some servers may not allow this.",
                () -> { Settings.airPlace = !Settings.airPlace; Settings.save(); rebuildWidgets(); });
        y += ROW;

        final int sy = y;
        SpeedSlider slider = new SpeedSlider(x0, sy, W);
        slider.setAlpha(0f);
        slider.setTooltip(Tooltip.create(Component.literal("How fast the printer places blocks (1 - 100). Higher is faster, but may be rejected by servers with anti-cheat.")));
        addRenderableWidget(slider);
        addRenderableOnly((g, mx, my, pt) -> {
            Hud.roundFill(g, x0, sy, W, H, 0x66000000);
            int pw = (int) Math.round(W * (Settings.speed - 1) / 99.0);
            if (pw >= 6) Hud.roundFill(g, x0, sy, pw, H, 0x5555CCFF);
            if (mx >= x0 && mx < x0 + W && my >= sy && my < sy + H) Hud.roundFill(g, x0, sy, W, H, 0x2255CCFF);
            Hud.roundFrame(g, x0, sy, W, H);
            String label = "Print Speed: " + Settings.speed;
            Hud.text(g, label, x0 + (W - Minecraft.getInstance().font.width(label)) / 2, sy + 6, 0xFFFFFFFF);
        });
        y += ROW;

        btn("Ghost Blocks: " + (Settings.ghost ? "On" : "Off"), x0, y, W,
                "Draws a blue box where a block is still missing and a red box where the wrong block is in the way.",
                () -> { Settings.ghost = !Settings.ghost; Settings.save(); rebuildWidgets(); });
        y += ROW + 5;
        btn("Back", x0, y, W, "Return to the main menu.", () -> go(Page.MAIN));
    }
}
