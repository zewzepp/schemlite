package dev.schemlite;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.util.List;

/** The M menu. Built only from buttons / text / one text box. Every button has a hover tooltip. */
public class MenuScreen extends Screen {
    private enum Page { MAIN, BUILDS, MATERIALS, SETTINGS, FILES }

    private Page page = Page.MAIN;
    private String nameText = "";
    private int buildPage = 0, matPage = 0;
    private boolean matAll = true;
    private int filesTab = 0;   // 0 = export, 1 = import, 2 = litematica
    private int filePage = 0;
    private String armedDelete = null;

    public MenuScreen() { super(Component.literal("SchemLite")); }

    private Button btn(String label, int x, int y, int w, String tip, Runnable r) {
        return btnF(label, null, x, y, w, tip, r);
    }

    /** Same as btn, but the label can be coloured (used to mark the active tab / active toggle). */
    private Button btnF(String label, net.minecraft.ChatFormatting fmt, int x, int y, int w, String tip, Runnable r) {
        Component text = fmt == null ? Component.literal(label) : Component.literal(label).withStyle(fmt);
        Button b = Button.builder(text, bt -> r.run()).bounds(x, y, w, 20).build();
        b.setAlpha(0f);   // see-through: the vanilla button art is invisible but the button still clicks and shows its tooltip
        addRenderableWidget(b);
        // 40% black tint, light blue outline just outside the button, plus a faint blue tint while the mouse is over it
        addRenderableOnly((g, mx, my, pt) -> {
            Hud.fill(g, x, y, x + w, y + 20, 0x66000000);   // 40% black tint
            if (mx >= x && mx < x + w && my >= y && my < y + 20) Hud.fill(g, x, y, x + w, y + 20, 0x3355CCFF);
            Hud.frame(g, x - 1, y - 1, x + w + 1, y + 21);
        });
        // our own centred label on top
        net.minecraft.client.gui.Font font = Minecraft.getInstance().font;
        int tw = font.width(text);
        addRenderableWidget(new StringWidget(x + (w - tw) / 2, y + 6, tw, 8, text, font));
        if (tip != null && !noTip(label)) b.setTooltip(Tooltip.create(Component.literal(tip)));
        return b;
    }

    /** Self-explanatory buttons get no hover text; only the ones that need explaining do. */
    private static boolean noTip(String label) {
        String[] plain = {"Rotate", "-", "+", "Save", "Builds", "Material", "Settings", "Clear", "Back", "<", ">",
                "Load", "Delete", "Sure", "All Blocks", "Missing Blocks", "Export", "[Export", "Import", "[Import", "Open "};
        for (String s : plain) if (label.startsWith(s)) return true;
        return false;
    }

    /** No background: just a light blue outline around the page. */
    private void panel(int x, int y, int w, int h) {
        addRenderableOnly((g, mx, my, pt) -> Hud.frame(g, x, y, x + w, y + h));
    }

    private void header(String s, int x, int y, int w) {
        addRenderableWidget(new StringWidget(x, y, w, 12,
                Component.literal(s).withStyle(net.minecraft.ChatFormatting.AQUA, net.minecraft.ChatFormatting.BOLD),
                Minecraft.getInstance().font));
    }

    private void text(String s, int x, int y, int w) {
        addRenderableWidget(new StringWidget(x, y, w, 12,
                Component.literal(s).withStyle(net.minecraft.ChatFormatting.GRAY), Minecraft.getInstance().font));
    }

    private void go(Page p) { page = p; armedDelete = null; rebuildWidgets(); }

    @Override
    protected void init() {
        int x0 = this.width / 2 - 100;
        int y = Math.max(14, this.height / 2 - 119);
        int ph = switch (page) { case MAIN -> 230; case BUILDS -> 192; case MATERIALS -> 202; case SETTINGS -> 160; case FILES -> 215; };
        panel(x0 - 10, y - 8, 220, ph);
        switch (page) {
            case MAIN -> main(x0, y);
            case BUILDS -> builds(x0, y);
            case MATERIALS -> materials(x0 - 70, y);
            case SETTINGS -> settings(x0, y);
            case FILES -> files(x0, y);
        }
    }

    // ------------------------------------------------------------------ MAIN
    private void main(int x0, int y) {
        header("SchemLite", x0, y, 200); y += 13;
        text(BP.status, x0, y, 200); y += 16;

        btn("Mode: " + BP.mode, x0, y, 98,
                "Switch between SELECT (pick two corners with the stick) and PLACE (position and print a loaded build).",
                () -> { BP.toggleMode(); rebuildWidgets(); });
        btn("Rotate: " + BP.rotDeg() + "° (R)", x0 + 102, y, 98,
                "Turn the loaded build 90° clockwise. Cycles 0° > 90° > 180° > 270° > back to 0°.",
                () -> { BP.rotate(); rebuildWidgets(); });
        y += 22;

        String[] lab = {"-X", "+X", "-Y", "+Y", "-Z", "+Z"};
        String[] tips = {"Move the build 1 block west.", "Move the build 1 block east.",
                "Move the build 1 block down.", "Move the build 1 block up.",
                "Move the build 1 block north.", "Move the build 1 block south."};
        int[][] d = {{-1, 0, 0}, {1, 0, 0}, {0, -1, 0}, {0, 1, 0}, {0, 0, -1}, {0, 0, 1}};
        for (int i = 0; i < 6; i++) {
            final int k = i;
            btn(lab[i], x0 + i * 34, y, 32, tips[i], () -> {
                if (BP.origin == null) BP.status = "Load or place a build first.";
                else { BP.origin = BP.origin.offset(d[k][0], d[k][1], d[k][2]); BP.status = "Moved to " + BP.origin.toShortString(); }
                rebuildWidgets();
            });
        }
        y += 22;

        text("Name of Build", x0, y, 200); y += 11;
        EditBox box = new EditBox(Minecraft.getInstance().font, x0, y, 200, 18, Component.literal("Name of Build"));
        box.setValue(nameText);
        box.setResponder(s -> nameText = s);
        addRenderableWidget(box);
        y += 22;

        btn("Save selection", x0, y, 98,
                "Save the blocks between your two selected corners as a build with the name above.",
                this::saveSelection);
        btn("Origin: Player", x0 + 102, y, 98,
                "Move the loaded build so its corner is at the block you are standing on.",
                () -> {
                    var p = Minecraft.getInstance().player;
                    if (p != null && BP.schem != null) { BP.origin = p.blockPosition(); BP.status = "Origin set to your position."; }
                    else BP.status = "Load a build first.";
                    rebuildWidgets();
                });
        y += 22;

        btn("Builds", x0, y, 98,
                "Open your saved builds. Load or delete them. Shared by every world.",
                () -> go(Page.BUILDS));
        btn("Material list", x0 + 102, y, 98,
                "Show every block (and how many) the loaded build needs.",
                () -> { matPage = 0; go(Page.MATERIALS); });
        y += 22;

        btn("Build Files", x0, y, 200,
                "Export your builds to share with other players, or import builds you received from them.",
                () -> { filePage = 0; go(Page.FILES); });
        y += 22;

        btn("Settings", x0, y, 98,
                "Change print key behaviour, print speed and other options.",
                () -> go(Page.SETTINGS));
        btn("Clear all", x0 + 102, y, 98,
                "Unload the current build and remove both selected corners.",
                () -> {
                    BP.clearSchem(); BP.showMissing = false; BP.origin = null; BP.pos1 = null; BP.pos2 = null;
                    BP.nextIsPos2 = false; BP.mode = BP.Mode.SELECT; BP.status = "Cleared.";
                    rebuildWidgets();
                });
        y += 22;

        // centered below Settings + Clear all
        btn("Back", x0 + 51, y, 98, "Close this menu.", this::onClose);
    }

    private void saveSelection() {
        Minecraft mc = Minecraft.getInstance();
        if (BP.pos1 == null || BP.pos2 == null || mc.level == null) {
            BP.status = "Pick two corners with the stick first."; rebuildWidgets(); return;
        }
        BlockPos a = BP.pos1, b = BP.pos2;
        long vol = (long) (Math.abs(a.getX() - b.getX()) + 1) * (Math.abs(a.getY() - b.getY()) + 1) * (Math.abs(a.getZ() - b.getZ()) + 1);
        if (vol > 8_000_000L) { BP.status = "Selection too big (max 8 million blocks)."; rebuildWidgets(); return; }
        String name = Library.clean(nameText);
        Schematic s = Schematic.capture(mc.level, a, b);
        try {
            s.save(Library.dir().resolve(name + ".sl"));
            BP.status = "Saved '" + name + "' (" + s.sx + "x" + s.sy + "x" + s.sz + ")";
        } catch (IOException e) { BP.status = "Save failed: " + e.getMessage(); }
        rebuildWidgets();
    }

    // ---------------------------------------------------------------- BUILDS
    private void builds(int x0, int y) {
        header("Builds - shared by every world", x0, y, 200); y += 16;
        List<String> names = Library.list();
        int per = 5;
        int pages = Math.max(1, (names.size() + per - 1) / per);
        buildPage = Math.max(0, Math.min(buildPage, pages - 1));
        if (names.isEmpty()) text("No builds yet. Save a selection first.", x0, y + 4, 200);
        for (int i = 0; i < per; i++) {
            int idx = buildPage * per + i;
            if (idx < names.size()) {
                final String n = names.get(idx);
                btn("Load: " + n, x0, y, 150, "Load this build and switch to PLACE mode.", () -> loadBuild(n));
                btn(n.equals(armedDelete) ? "Sure?" : "Delete", x0 + 154, y, 46,
                        "Delete this build permanently. Click twice to confirm.", () -> {
                    if (n.equals(armedDelete)) { Library.delete(n); armedDelete = null; BP.status = "Deleted " + n; }
                    else armedDelete = n;
                    rebuildWidgets();
                });
            }
            y += 22;
        }
        btn("<", x0, y, 40, "Previous page.", () -> { buildPage--; rebuildWidgets(); });
        text("Page " + (buildPage + 1) + "/" + pages, x0 + 76, y + 5, 60);
        btn(">", x0 + 160, y, 40, "Next page.", () -> { buildPage++; rebuildWidgets(); });
        y += 24;
        text("To share or import builds, use Build Files.", x0 - 10, y, 220); y += 14;
        btn("Back", x0, y, 200, "Return to the main menu.", () -> go(Page.MAIN));
    }

    private void loadBuild(String name) {
        var p = Minecraft.getInstance().player;
        try {
            BP.setSchem(Schematic.load(Library.dir().resolve(name + ".sl")));
            BP.origin = p != null ? p.blockPosition() : BlockPos.ZERO;
            BP.mode = BP.Mode.PLACE;
            BP.status = "Loaded '" + name + "'. Right-click with stick to move it.";
            onClose();
        } catch (IOException e) { BP.status = "Load failed: " + e.getMessage(); rebuildWidgets(); }
    }

    // ------------------------------------------------------------- MATERIALS
    private void materials(int x0, int y) {
        header("Material list", x0 + 70, y, 200); y += 16;
        btnF("All Blocks", matAll ? net.minecraft.ChatFormatting.YELLOW : null, x0 + 70, y, 58,
                "Show every block the whole build needs.",
                () -> { matAll = true; matPage = 0; rebuildWidgets(); });
        btnF("Missing Blocks", !matAll ? net.minecraft.ChatFormatting.YELLOW : null, x0 + 130, y, 80,
                "Show only the materials that are still missing.",
                () -> { matAll = false; matPage = 0; rebuildWidgets(); });
        btnF("Highlight", BP.showMissing ? net.minecraft.ChatFormatting.RED : null, x0 + 212, y, 58,
                "Outline every block that is still missing in the world, in pulsing red, even through walls. Click again to turn it off.",
                () -> { BP.toggleHighlight(); rebuildWidgets(); });
        y += 24;
        List<String> lines = Materials.compute(matAll);
        int per = 8;
        int pages = Math.max(1, (lines.size() + per - 1) / per);
        matPage = Math.max(0, Math.min(matPage, pages - 1));
        for (int i = 0; i < per; i++) {
            int idx = matPage * per + i;
            if (idx < lines.size()) text(lines.get(idx), x0 + 70, y, 200);
            y += 13;
        }
        y += 6;
        btn("<", x0 + 70, y, 40, "Previous page.", () -> { matPage--; rebuildWidgets(); });
        text("Page " + (matPage + 1) + "/" + pages, x0 + 146, y + 5, 60);
        btn(">", x0 + 230, y, 40, "Next page.", () -> { matPage++; rebuildWidgets(); });
        y += 24;
        btn("Back", x0 + 70, y, 200, "Return to the main menu.", () -> go(Page.MAIN));
    }

    // ----------------------------------------------------------------- FILES
    private void files(int x0, int y) {
        header("Build Files", x0, y, 200); y += 13;
        text(BP.status, x0, y, 200); y += 16;
        String[] tn = {"Export", "Import", "Litematica"};
        String[] tt = {"Copy one of your builds to the exports folder so you can send the file to another player.",
                "Add a build file you received from another player to your builds.",
                "Use a .litematic file from Litematica: it is converted, saved to your builds and loaded ready to place."};
        int[] tw = {64, 64, 68};
        int tx = x0;
        for (int i = 0; i < 3; i++) {
            final int k = i;
            btn(filesTab == i ? "[" + tn[i] + "]" : tn[i], tx, y, tw[i], tt[i], () -> { filesTab = k; filePage = 0; rebuildWidgets(); });
            tx += tw[i] + 2;
        }
        y += 24;

        List<String> names = filesTab == 0 ? Library.list()
                : filesTab == 1 ? Library.listIn(Library.importDir())
                : Library.listIn(Library.litematicaDir(), ".litematic");
        int per = 4;
        int pages = Math.max(1, (names.size() + per - 1) / per);
        filePage = Math.max(0, Math.min(filePage, pages - 1));
        if (names.isEmpty()) {
            text(filesTab == 0 ? "No builds to export. Save a selection first."
                    : filesTab == 1 ? "No files found in the imports folder."
                    : "No .litematic files in .minecraft/schematics.", x0, y + 4, 200);
        }
        for (int i = 0; i < per; i++) {
            int idx = filePage * per + i;
            if (idx < names.size()) {
                final String n = names.get(idx);
                if (filesTab == 0) {
                    btn("Export: " + n, x0, y, 200,
                            "Copy this build to the exports folder. Use 'Open Export Folder' to find the file and send it.",
                            () -> {
                                try { Library.export(n); BP.status = "Exported '" + n + "'. Open the export folder."; }
                                catch (IOException e) { BP.status = "Export failed: " + e.getMessage(); }
                                rebuildWidgets();
                            });
                } else if (filesTab == 1) {
                    btn("Import: " + n, x0, y, 200,
                            "Add this file to your builds. It will then show up in Builds.",
                            () -> {
                                try { BP.status = "Imported as '" + Library.importFile(n) + "'."; }
                                catch (Exception e) { BP.status = "Import failed: not a valid build file."; }
                                rebuildWidgets();
                            });
                } else {
                    btn("Use: " + n, x0, y, 200,
                            "Convert this Litematica file, save it to your builds under the same name and load it at your position. Right-click with a stick to move it.",
                            () -> useLitematic(n));
                }
            }
            y += 22;
        }
        btn("<", x0, y, 40, "Previous page.", () -> { filePage--; rebuildWidgets(); });
        text("Page " + (filePage + 1) + "/" + pages, x0 + 76, y + 5, 60);
        btn(">", x0 + 160, y, 40, "Next page.", () -> { filePage++; rebuildWidgets(); });
        y += 24;

        btn(filesTab == 0 ? "Open Export Folder" : filesTab == 1 ? "Open Import Folder" : "Open Litematica Folder", x0, y, 200,
                filesTab == 0 ? "Open the folder with your exported builds. Send these .sl files to other players."
                : filesTab == 1 ? "Open the folder where received .sl files go. Drop the files here, then come back and click Import."
                : "Open .minecraft/schematics, where Litematica saves its .litematic files.",
                () -> Library.openFolder(filesTab == 0 ? Library.exportDir() : filesTab == 1 ? Library.importDir() : Library.litematicaDir()));
        y += 22;
        btn("Back", x0, y, 200, "Return to the main menu.", () -> go(Page.MAIN));
    }

    private void useLitematic(String fileName) {
        var p = Minecraft.getInstance().player;
        try {
            Schematic s = Litematica.read(Library.litematicaDir().resolve(fileName + ".litematic"));
            String name = Library.clean(fileName);
            s.save(Library.dir().resolve(name + ".sl"));
            BP.setSchem(s);
            BP.origin = p != null ? p.blockPosition() : BlockPos.ZERO;
            BP.mode = BP.Mode.PLACE;
            BP.status = "Loaded '" + name + "' from Litematica.";
            onClose();
        } catch (Exception e) {
            BP.status = "Litematica import failed: " + e.getMessage();
            rebuildWidgets();
        }
    }

    // -------------------------------------------------------------- SETTINGS
    private void settings(int x0, int y) {
        header("Settings", x0, y, 200); y += 16;
        btn("Print Key: " + (Settings.printToggle ? "Toggle" : "Hold"), x0, y, 200,
                "Hold: the printer runs only while you hold the print key. Toggle: press once to start printing, press again to stop.",
                () -> { Settings.printToggle = !Settings.printToggle; Printer.toggled = false; Settings.save(); rebuildWidgets(); });
        y += 22;
        btn("Air place: " + (Settings.airPlace ? "ON" : "OFF"), x0, y, 200,
                "Allows placing blocks that have no neighbouring block to attach to (floating blocks). Some servers may not allow this.",
                () -> { Settings.airPlace = !Settings.airPlace; Settings.save(); rebuildWidgets(); });
        y += 22;
        btn("Print speed: " + Settings.bps() + " blocks/sec", x0, y, 200,
                "How many blocks the printer places per second. Higher is faster, but may be rejected by servers with anti-cheat.",
                () -> { Settings.speedIdx = (Settings.speedIdx + 1) % Settings.SPEEDS.length; Settings.save(); rebuildWidgets(); });
        y += 22;
        String[] sm = {"OFF", "Sneak + Scroll", "Scroll"};
        btn("Mode switch: " + sm[Settings.scrollMode], x0, y, 200,
                "How to switch between SELECT and PLACE while holding a stick: OFF, Sneak + Scroll, or just Scroll.",
                () -> { Settings.scrollMode = (Settings.scrollMode + 1) % 3; Settings.save(); rebuildWidgets(); });
        y += 22;
        btn("Ghost boxes: " + (Settings.ghost ? "ON" : "OFF"), x0, y, 200,
                "Draws a blue box where a block is still missing and a red box where the wrong block is in the way.",
                () -> { Settings.ghost = !Settings.ghost; Settings.save(); rebuildWidgets(); });
        y += 28;
        btn("Back", x0, y, 200, "Return to the main menu.", () -> go(Page.MAIN));
    }
}
