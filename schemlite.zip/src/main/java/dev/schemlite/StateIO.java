package dev.schemlite;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

import java.util.*;

/** Stable text keys for block states, independent of NBT/codec API changes. */
public final class StateIO {
    private static Map<String, BlockState> lookup;

    public static String key(BlockState s) {
        StringBuilder sb = new StringBuilder(BuiltInRegistries.BLOCK.getKey(s.getBlock()).toString());
        List<Property<?>> props = new ArrayList<>(s.getProperties());
        if (!props.isEmpty()) {
            props.sort((a, b) -> a.getName().compareTo(b.getName()));
            sb.append('[');
            for (int i = 0; i < props.size(); i++) {
                if (i > 0) sb.append(',');
                sb.append(props.get(i).getName()).append('=').append(valueName(props.get(i), s));
            }
            sb.append(']');
        }
        return sb.toString();
    }

    private static <T extends Comparable<T>> String valueName(Property<T> p, BlockState s) {
        return p.getName(s.getValue(p));
    }

    /** Returns null if the block no longer exists. */
    public static BlockState parse(String key) {
        if (lookup == null) {
            lookup = new HashMap<>();
            for (Block b : BuiltInRegistries.BLOCK) {
                for (BlockState st : b.getStateDefinition().getPossibleStates()) lookup.put(key(st), st);
            }
        }
        return lookup.get(key);
    }
    private StateIO() {}
}
