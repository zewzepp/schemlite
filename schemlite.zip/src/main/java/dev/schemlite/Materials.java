package dev.schemlite;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.SlabType;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public final class Materials {
    /** @param all true = whole build, false = only what's still missing in the world */
    public static List<String> compute(boolean all) {
        List<String> out = new ArrayList<>();
        Minecraft mc = Minecraft.getInstance();
        Schematic s = BP.schem;
        if (s == null || mc.player == null || mc.level == null) { out.add("No build loaded."); return out; }
        if (!all && BP.origin == null) { out.add("Place the build first."); return out; }

        Map<Item, Integer> need = new HashMap<>();
        for (int y = 0; y < s.sy; y++) for (int z = 0; z < s.sz; z++) for (int x = 0; x < s.sx; x++) {
            BlockState st = s.get(x, y, z);
            if (Printer.skip(st)) continue;
            if (!all && mc.level.getBlockState(BP.origin.offset(x, y, z)) == st) continue;
            int n = (st.getBlock() instanceof SlabBlock && st.getValue(SlabBlock.TYPE) == SlabType.DOUBLE) ? 2 : 1;
            need.merge(st.getBlock().asItem(), n, Integer::sum);
        }
        if (need.isEmpty()) { out.add(all ? "Build is empty." : "Nothing missing - build complete!"); return out; }

        List<Map.Entry<Item, Integer>> sorted = new ArrayList<>(need.entrySet());
        sorted.sort((x, y) -> y.getValue() - x.getValue());
        for (var e : sorted) {
            String name = new ItemStack(e.getKey()).getHoverName().getString();
            out.add(name + " (" + e.getValue() + "x)");
        }
        try {
            Path f = FabricLoader.getInstance().getConfigDir().resolve("schemlite").resolve("materials.txt");
            Files.createDirectories(f.getParent());
            Files.writeString(f, String.join("\n", out));
        } catch (Exception ignored) { }
        return out;
    }
    private Materials() {}
}
