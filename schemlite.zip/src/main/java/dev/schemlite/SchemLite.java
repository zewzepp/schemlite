package dev.schemlite;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Items;

public class SchemLite implements ClientModInitializer {
    static KeyMapping PRINT, ROTATE, MODE, MENU, HIGHLIGHT;

    private static KeyMapping key(String id, int code, KeyMapping.Category cat) {
        return KeyMappingHelper.registerKeyMapping(new KeyMapping("key.schemlite." + id, InputConstants.Type.values()[0], code, cat));
    }

    @Override
    public void onInitializeClient() {
        Settings.load();
        KeyMapping.Category cat = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("schemlite", "main"));
        PRINT = key("print", 86, cat);    // V
        ROTATE = key("rotate", 82, cat);  // R
        MODE = key("mode", 90, cat);      // Z
        MENU = key("menu", 77, cat);      // M
        HIGHLIGHT = key("highlight", 89, cat);   // Y

        // ---- Stick tool: right-click a block (sneak = normal vanilla use) ----
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (Printer.placing || Printer.running || Printer.toggled || !level.isClientSide() || hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
            if (!player.getMainHandItem().is(Items.STICK) || player.isShiftKeyDown()) return InteractionResult.PASS;
            if (BP.mode == BP.Mode.SELECT) {
                BlockPos p = hit.getBlockPos();
                if (!BP.nextIsPos2) { BP.pos1 = p; BP.msg("Corner 1 set " + p.toShortString()); BP.actionBar("Corner 1 set"); }
                else { BP.pos2 = p; BP.msg("Corner 2 set " + p.toShortString()); BP.actionBar("Corner 2 set"); }
                BP.nextIsPos2 = !BP.nextIsPos2;
            } else if (BP.schem != null) {
                BP.origin = hit.getBlockPos().relative(hit.getDirection());
                BP.msg("Origin set " + BP.origin.toShortString());
            }
            return InteractionResult.SUCCESS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            LocalPlayer p = mc.player;
            if (p == null || mc.level == null) { Printer.reset(); return; }

            while (MENU.consumeClick()) BP.openScreen(new MenuScreen());
            while (MODE.consumeClick()) BP.toggleMode();
            while (ROTATE.consumeClick()) BP.rotate();
            while (HIGHLIGHT.consumeClick()) BP.toggleHighlight();

            boolean want;
            if (Settings.printToggle) {
                while (PRINT.consumeClick()) Printer.toggled = !Printer.toggled;
                want = Printer.toggled;
            } else {
                while (PRINT.consumeClick()) { }
                Printer.toggled = false;
                want = PRINT.isDown();
            }
            if (want && BP.schem != null && BP.origin != null && BP.mode == BP.Mode.PLACE) {
                Printer.running = true;
                Printer.tick(mc);
            } else {
                Printer.running = false;
                Printer.stop(mc);
            }
        });

        LevelRenderEvents.BEFORE_GIZMOS.register(ctx -> Overlay.render());
        Hud.register();
    }
}
