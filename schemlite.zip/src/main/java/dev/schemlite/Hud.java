package dev.schemlite;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.resources.Identifier;

import java.lang.reflect.Method;

/**
 * Bottom-left on-screen display: current mode (SELECT / PLACE), rotation and printing state.
 * Drawing goes through reflection so it survives the GuiGraphics method renames between versions.
 */
public final class Hud {
    private static Method textM, fillM;
    private static boolean resolved = false;

    public static void register() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("schemlite", "mode_hud"),
                (g, tick) -> draw(g));
    }

    private static void resolve(Object g) {
        resolved = true;
        for (Method m : g.getClass().getMethods()) {
            Class<?>[] p = m.getParameterTypes();
            String n = m.getName();
            if (textM == null && (n.equals("text") || n.equals("drawString")) && p.length == 5
                    && p[0] == Font.class && p[1] == String.class
                    && p[2] == int.class && p[3] == int.class && p[4] == int.class) textM = m;
            if (fillM == null && n.equals("fill") && p.length == 5
                    && p[0] == int.class && p[1] == int.class && p[2] == int.class
                    && p[3] == int.class && p[4] == int.class) fillM = m;
        }
    }

    private static void draw(Object g) {
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null || !mc.player.getMainHandItem().is(net.minecraft.world.item.Items.STICK)) return;
            if (!resolved) resolve(g);
            if (textM == null) return;

            String printing = Printer.running ? "Printing..." : null;
            String mode = "Mode: " + BP.mode;
            String rotation = "Rotation: " + BP.rotDeg() + "°";
            String missing = "Missing Blocks: " + (BP.showMissing ? "ON" : "OFF");
            String[] lines = printing == null
                    ? new String[]{mode, rotation, missing}
                    : new String[]{printing, mode, rotation, missing};
            int h = mc.getWindow().getGuiScaledHeight();
            Font f = mc.font;
            int w = 0;
            for (String line : lines) w = Math.max(w, f.width(line));
            int x = 6, y = h - 7 - lines.length * 11;
            if (fillM != null) fillM.invoke(g, x - 3, y - 3, x + w + 5, y + lines.length * 11 + 2, 0xB0202630);
            for (int i = 0; i < lines.length; i++) {
                int color = (printing != null && i == 0) ? 0xFF70F0A0 : (lines[i].startsWith("Mode:") ? 0xFFFFD66B : 0xFFF2F4FA);
                textM.invoke(g, f, lines[i], x, y + i * 11, color);
            }
        } catch (Throwable ignored) { }
    }
    private Hud() {}
}
