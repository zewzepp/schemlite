package dev.schemlite;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.resources.Identifier;

import java.lang.reflect.Method;

/**
 * Bottom-left on-screen display: current mode (SELECT / PLACE), rotation and printing state.
 * Drawing goes through reflection so it survives the GuiGraphics method renames between versions.
 */
public final class Hud {
    private static Method textM, fillM;
    private static boolean resolved = false;

    public static void register() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("schemlite", "mode_hud"),
                (g, tick) -> draw(g));
    }

    private static void resolve(Object g) {
        resolved = true;
        for (Method m : g.getClass().getMethods()) {
            Class<?>[] p = m.getParameterTypes();
            String n = m.getName();
            if (textM == null && (n.equals("text") || n.equals("drawString")) && p.length == 5
                    && p[0] == Font.class && p[1] == String.class
                    && p[2] == int.class && p[3] == int.class && p[4] == int.class) textM = m;
            if (fillM == null && n.equals("fill") && p.length == 5
                    && p[0] == int.class && p[1] == int.class && p[2] == int.class
                    && p[3] == int.class && p[4] == int.class) fillM = m;
        }
    }

    private static void draw(Object g) {
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null) return;
            if (!resolved) resolve(g);
            if (textM == null) return;

            boolean place = BP.mode == BP.Mode.PLACE;
            String l1 = "Mode: " + BP.mode;
            String l2 = null;
            if (BP.schem != null) {
                l2 = "Rotation: " + BP.rotDeg() + "°" + (Printer.running ? "  |  Printing" : "") + (BP.showMissing ? "  |  Missing: ON" : "");
            }
            int h = mc.getWindow().getGuiScaledHeight();
            Font f = mc.font;
            String l3 = (Printer.running && Printer.note != null) ? Printer.note : null;
            int lines = 1 + (l2 == null ? 0 : 1) + (l3 == null ? 0 : 1);
            int w = Math.max(f.width(l1), Math.max(l2 == null ? 0 : f.width(l2), l3 == null ? 0 : f.width(l3)));
            int x = 4, y = h - 4 - lines * 10;
            if (fillM != null) fillM.invoke(g, x - 2, y - 2, x + w + 2, y + lines * 10, 0x80000000);
            textM.invoke(g, f, l1, x, y, place ? 0xFF55FF55 : 0xFFFFFF55);
            if (l2 != null) textM.invoke(g, f, l2, x, y + 10, 0xFFFFFFFF);
            if (l3 != null) textM.invoke(g, f, l3, x, y + (l2 == null ? 10 : 20), 0xFFFF5555);
        } catch (Throwable ignored) { }
    }
    private Hud() {}
}
