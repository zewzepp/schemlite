package dev.schemlite;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Items;

import java.lang.reflect.Method;

/**
 * Bottom-left on-screen display: current mode (SELECT / PLACE), rotation and printing state.
 * Drawing goes through reflection so it survives the GuiGraphics method renames between versions.
 */
public final class Hud {
    private static Method textM, fillM, textShadowM;
    private static boolean resolved = false;

    public static void register() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("schemlite", "mode_hud"),
                (g, tick) -> draw(g));
    }

    public static void fill(Object g, int x1, int y1, int x2, int y2, int color) {
        try {
            if (!resolved) resolve(g);
            if (fillM != null) fillM.invoke(g, x1, y1, x2, y2, color);
        } catch (Throwable ignored) { }
    }

    /** 1px light blue outline just inside the given rectangle. */
    public static void frame(Object g, int x1, int y1, int x2, int y2) {
        try {
            if (!resolved) resolve(g);
            if (fillM == null) return;
            int c = 0xFF55CCFF;
            fillM.invoke(g, x1, y1, x2, y1 + 1, c);
            fillM.invoke(g, x1, y2 - 1, x2, y2, c);
            fillM.invoke(g, x1, y1, x1 + 1, y2, c);
            fillM.invoke(g, x2 - 1, y1, x2, y2, c);
        } catch (Throwable ignored) { }
    }

    private static void resolve(Object g) {
        resolved = true;
        for (Method m : g.getClass().getMethods()) {
            Class<?>[] p = m.getParameterTypes();
            String n = m.getName();
            if (textM == null && (n.equals("text") || n.equals("drawString")) && p.length == 5
                    && p[0] == Font.class && p[1] == String.class
                    && p[2] == int.class && p[3] == int.class && p[4] == int.class) textM = m;
            if (textShadowM == null && (n.equals("text") || n.equals("drawString")) && p.length == 6
                    && p[0] == Font.class && p[1] == String.class
                    && p[2] == int.class && p[3] == int.class && p[4] == int.class && p[5] == boolean.class) textShadowM = m;
            if (fillM == null && n.equals("fill") && p.length == 5
                    && p[0] == int.class && p[1] == int.class && p[2] == int.class
                    && p[3] == int.class && p[4] == int.class) fillM = m;
        }
    }

    private static void draw(Object g) {
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null) return;
            if (!resolved) resolve(g);
            if (textM == null) return;

            boolean holdingStick = mc.player.getMainHandItem().is(Items.STICK);
            if (!holdingStick && !Printer.running) return;   // only show while holding the stick (or printing)

            boolean place = BP.mode == BP.Mode.PLACE;
            java.util.List<String> lines = new java.util.ArrayList<>();
            java.util.List<Integer> cols = new java.util.ArrayList<>();
            if (Printer.running) { lines.add("Printing..."); cols.add(0xFF55CCFF); }
            lines.add("Mode: " + BP.mode); cols.add(place ? 0xFF55FF55 : 0xFFFFFF55);
            lines.add("Rotation: " + BP.rotDeg() + "°"); cols.add(0xFFFFFFFF);
            String miss = "Missing Blocks: " + (BP.showMissing
                    ? "ON (" + Overlay.missingN + (Overlay.missingN >= 3000 ? "+" : "") + ")" : "OFF");
            lines.add(miss); cols.add(BP.showMissing ? 0xFFFF5555 : 0xFFAAAAAA);
            if (Printer.running && Printer.note != null) { lines.add(Printer.note); cols.add(0xFFFFAA00); }

            int h = mc.getWindow().getGuiScaledHeight();
            Font f = mc.font;
            int w = 0;
            for (String l : lines) w = Math.max(w, f.width(l));
            int x = 4, y = h - 4 - lines.size() * 10;
            if (fillM != null) {
                int bottom = y + lines.size() * 10 + 1;
                fillM.invoke(g, x - 3, y - 3, x + w + 5, bottom, 0x80000000);   // see-through dark tint
                frame(g, x - 3, y - 3, x + w + 5, bottom);                       // light blue outline only (no background)
            }
            for (int i = 0; i < lines.size(); i++) {
                if (textShadowM != null) textShadowM.invoke(g, f, lines.get(i), x + 2, y + i * 10, cols.get(i), true);
                else textM.invoke(g, f, lines.get(i), x + 2, y + i * 10, cols.get(i));
            }
        } catch (Throwable ignored) { }
    }
    private Hud() {}
}
