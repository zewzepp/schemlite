package dev.schemlite;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Items;

import java.lang.reflect.Method;

/**
 * Bottom-left on-screen display: current mode (SELECT / PLACE), rotation and printing state.
 * Drawing goes through reflection so it survives the GuiGraphics method renames between versions.
 */
public final class Hud {
    private static Method textM, fillM, textShadowM;
    private static boolean resolved = false;

    public static void register() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("schemlite", "mode_hud"),
                (g, tick) -> draw(g));
    }

    public static void fill(Object g, int x1, int y1, int x2, int y2, int color) {
        try {
            if (!resolved) resolve(g);
            if (fillM != null) fillM.invoke(g, x1, y1, x2, y2, color);
        } catch (Throwable ignored) { }
    }

    /** 1px light blue outline just inside the given rectangle. */
    public static void frame(Object g, int x1, int y1, int x2, int y2) {
        try {
            if (!resolved) resolve(g);
            if (fillM == null) return;
            int c = 0xFF55CCFF;
            fillM.invoke(g, x1, y1, x2, y1 + 1, c);
            fillM.invoke(g, x1, y2 - 1, x2, y2, c);
            fillM.invoke(g, x1, y1, x1 + 1, y2, c);
            fillM.invoke(g, x2 - 1, y1, x2, y2, c);
        } catch (Throwable ignored) { }
    }


    // ------------------------------------------------------------ rounded shapes
    public static final int FRAME_COLOR = 0xFF55CCFF;
    private static final int MAX_RADIUS = 8;   // 40% of a 20px button

    private static int radius(int w, int h) { return Math.max(0, Math.min(MAX_RADIUS, Math.min(w, h) / 2)); }

    /** How many pixels row i (of h) is pulled in from the left/right edge by the corner curve. */
    private static int inset(int r, int h, int i) {
        if (r <= 0) return 0;
        int d = Math.min(i, h - 1 - i);
        if (d >= r) return 0;
        double dyc = r - (d + 0.5);
        double dx = Math.sqrt(Math.max(0, r * (double) r - dyc * dyc));
        return (int) Math.round(r - dx);
    }

    /** Filled rectangle with rounded corners. */
    public static void roundFill(Object g, int x, int y, int w, int h, int color) {
        try {
            if (!resolved) resolve(g);
            if (fillM == null || w <= 0 || h <= 0) return;
            int r = radius(w, h);
            int i = 0;
            while (i < h) {
                int ins = inset(r, h, i);
                int j = i + 1;
                while (j < h && inset(r, h, j) == ins) j++;
                fillM.invoke(g, x + ins, y + i, x + w - ins, y + j, color);
                i = j;
            }
        } catch (Throwable ignored) { }
    }

    /** 1px outline with rounded corners (drawn inside the given box). */
    public static void roundFrame(Object g, int x, int y, int w, int h) {
        try {
            if (!resolved) resolve(g);
            if (fillM == null || w <= 2 || h <= 2) return;
            int r = radius(w, h), ri = Math.max(0, r - 1);
            int c = FRAME_COLOR;
            int i = 0;
            while (i < h) {
                int ins = inset(r, h, i);
                if (i == 0 || i == h - 1) {
                    fillM.invoke(g, x + ins, y + i, x + w - ins, y + i + 1, c);
                    i++;
                    continue;
                }
                int in = Math.max(inset(ri, h - 2, i - 1) + 1, ins + 1);
                int j = i + 1;
                while (j < h - 1) {
                    int ins2 = inset(r, h, j);
                    int in2 = Math.max(inset(ri, h - 2, j - 1) + 1, ins2 + 1);
                    if (ins2 != ins || in2 != in) break;
                    j++;
                }
                fillM.invoke(g, x + ins, y + i, x + in, y + j, c);
                fillM.invoke(g, x + w - in, y + i, x + w - ins, y + j, c);
                i = j;
            }
        } catch (Throwable ignored) { }
    }

    /** Draws a string with shadow at x, y. */
    public static void text(Object g, String s, int x, int y, int color) {
        try {
            if (!resolved) resolve(g);
            Font f = Minecraft.getInstance().font;
            if (textShadowM != null) textShadowM.invoke(g, f, s, x, y, color, true);
            else if (textM != null) textM.invoke(g, f, s, x, y, color);
        } catch (Throwable ignored) { }
    }

    private static void resolve(Object g) {
        resolved = true;
        for (Method m : g.getClass().getMethods()) {
            Class<?>[] p = m.getParameterTypes();
            String n = m.getName();
            if (textM == null && (n.equals("text") || n.equals("drawString")) && p.length == 5
                    && p[0] == Font.class && p[1] == String.class
                    && p[2] == int.class && p[3] == int.class && p[4] == int.class) textM = m;
            if (textShadowM == null && (n.equals("text") || n.equals("drawString")) && p.length == 6
                    && p[0] == Font.class && p[1] == String.class
                    && p[2] == int.class && p[3] == int.class && p[4] == int.class && p[5] == boolean.class) textShadowM = m;
            if (fillM == null && n.equals("fill") && p.length == 5
                    && p[0] == int.class && p[1] == int.class && p[2] == int.class
                    && p[3] == int.class && p[4] == int.class) fillM = m;
        }
    }

    private static void draw(Object g) {
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null) return;
            if (!resolved) resolve(g);
            if (textM == null) return;

            boolean holdingStick = mc.player.getMainHandItem().is(Items.STICK);
            if (!holdingStick && !Printer.running) return;   // only show while holding the stick (or printing)

            boolean place = BP.mode == BP.Mode.PLACE;
            java.util.List<String> lines = new java.util.ArrayList<>();
            java.util.List<Integer> cols = new java.util.ArrayList<>();
            if (Printer.running) { lines.add("Printing..."); cols.add(0xFF55CCFF); }
            lines.add("Mode: " + BP.mode); cols.add(place ? 0xFF55FF55 : 0xFFFFFF55);
            lines.add("Rotation: " + BP.rotDeg() + "°"); cols.add(0xFFFFFFFF);
            String miss = "Missing Blocks: " + (BP.showMissing
                    ? "ON (" + Overlay.missingN + (Overlay.missingN >= 3000 ? "+" : "") + ")" : "OFF");
            lines.add(miss); cols.add(BP.showMissing ? 0xFFFF5555 : 0xFFAAAAAA);
            if (Printer.running && Printer.note != null) { lines.add(Printer.note); cols.add(0xFFFFAA00); }

            int h = mc.getWindow().getGuiScaledHeight();
            Font f = mc.font;
            int w = 0;
            for (String l : lines) w = Math.max(w, f.width(l));
            int n = lines.size();
            int rectW = w + 14, rectH = n * 10 + 6;
            int rectX = 3, rectY = h - 3 - rectH;
            int tx = rectX + 7, ty = rectY + 4;
            roundFill(g, rectX, rectY, rectW, rectH, 0x80000000);   // see-through dark tint, rounded corners
            roundFrame(g, rectX, rectY, rectW, rectH);                // light blue rounded outline
            for (int i = 0; i < n; i++) {
                if (textShadowM != null) textShadowM.invoke(g, f, lines.get(i), tx, ty + i * 10, cols.get(i), true);
                else textM.invoke(g, f, lines.get(i), tx, ty + i * 10, cols.get(i));
            }
        } catch (Throwable ignored) { }
    }
    private Hud() {}
}
